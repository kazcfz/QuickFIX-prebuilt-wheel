#include <memory>

int main(int argc, char** argv)
{
  std::shared_ptr<int> o;
}
